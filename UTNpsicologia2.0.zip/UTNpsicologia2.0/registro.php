<!DOCTYPE>
<Html>
<Head>
<meta charset="utf-8">
<title>Insertar</title>
</head>
<body>
    
    <?php
    $server= "localhost";
    $usuario= "root";
    $contraseña= "";
    $bd= "psicologia";
    $conexion=mysqli_connect($server, $usuario, $contraseña, $bd) or die ("Error en la conexion");

    $matricula=$_POST['matricula'];
    $nombre=$_POST['nombre'];
    $apellidopaterno=$_POST['apellidopaterno'];
    $apellidomaterno=$_POST['apellidomaterno'];
    $cuatri_encurso=$_POST['cuatri_encurso'];
    $grupo=$_POST['grupo'];
    $correo=$_POST['correo'];
    $num_tel=$_POST['num_tel'];
    $contraseña=$_POST['contraseña'];


    $insertar="INSERT into registro values( '$idRegistro', '$matricula','$nombre','$apellidopaterno','$apellidomaterno','$cuatri_encurso','$grupo','$correo','$num_tel','$contraseña')";
    $resultado=mysqli_query($conexion, $insertar)

    or die ("Error al insertar registros");

    if($resultado)
    header("location:registro-exito.html");

    mysqli_close($conexion);
    ?>
    </body>
</html>