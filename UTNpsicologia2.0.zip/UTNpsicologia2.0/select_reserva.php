<?php
include("conexion.php");
$con = connection();

$sql = "SELECT * FROM reserva";
$query = mysqli_query($con, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTNpsicologia</title>
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Estilos Footer -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <title>UTNpsicologia</title>

</head>

<body>
    <header>
        <h2 class="logo">UTNpsicologia</h2>
        <input type="checkbox" id="check">
        <label for="check" class="mostrar-menu">
            &#8801
        </label>
        <nav class="menu">
            <a href="index.html">Inicio</a>
            <a href="formulario.html">Iniciar sesion</a>
            <a href="horario.html">Horario</a>
            <a href="http://www.utnogales.edu.mx/">Volver a UTN</a>
            <label for="check" class="esconder-menu">
                &#215
            </label>
        </nav>
    </header>
    <br>
    <div class="users-table">
        <h2>Administrador</h2>
        <table>
            <thead>
                <tr>
                    <th>idReserva</th>
                    <th>matricula</th>
                    <th>hora</th>
                    <th>fecha</th>
                    <th>lugar_servicio</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_array($query)): ?>
                    <tr>
                        <th><?= $row['idReserva'] ?></th>
                        <th><?= $row['matricula'] ?></th>
                        <th><?= $row['hora'] ?></th>
                        <th><?= $row['fecha'] ?></th>
                        <th><?= $row['lugar_servicio'] ?></th>
                        <th><a href="delete_reserva.php?idReserva=<?= $row['idReserva'] ?>" class="users-table--delete" >Eliminar</a></th>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="contenido-informacion">
            <a href="index.html" class="boton-reservar">Volver a pagina principal</a>
        </div>
    </div>
    <br>
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">UTNpsicologia</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            Av. Universidad #271, Colonia Universitaria, Nogales, Sonora, México. C.P. 84097
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:010-020-0340">31-118-13, 44 Ext. 2234</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none"
                                href="mailto:info@company.com">jnorzagaray@utnogales.edu.mx</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Secciones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="index.html">Inicio</a></li>
                        <li><a class="text-decoration-none" href="horario.html">Consultar Horarios</a></li>
                        <li><a class="text-decoration-none" href="http://www.utnogales.edu.mx/">Volver a UTN</a></li>
                    </ul>
                </div>
                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Acciones</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="formulario.html">Iniciar Sesion</a></li>
                        <li><a class="text-decoration-none" href="registro.html">Registrarse</a></li>
                        <li><a class="text-decoration-none" href="reservarcita.html">Reservar Cita</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; 2023 Shrimp Studio
                            | Trabajo en progreso por: <a rel="sponsored" href="#" target="_blank">Shrimp Studio</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>

</body>

</html>