<!DOCTYPE>
<Html>
<Head>
<meta charset="utf-8">
<title>Insertar</title>
</head>
<body>
    
    <?php
    $server= "localhost";
    $usuario= "root";
    $contraseña= "";
    $bd= "psicologia";
    $conexion=mysqli_connect($server, $usuario, $contraseña, $bd) or die ("Error en la conexion");

    $matricula=$_POST['matricula'];
    $correo=$_POST['correo'];
    $contraseña=$_POST['contraseña'];

    $insertar="INSERT into savesesion values( '$idSave', '$matricula', '$correo', '$contraseña')";
    $resultado=mysqli_query($conexion, $insertar)

    or die ("Error al insertar registros");

    if($resultado)
    header("location: http://localhost/UTNpsicologia/index.html");

    mysqli_close($conexion);
    ?>
    </body>
</html>