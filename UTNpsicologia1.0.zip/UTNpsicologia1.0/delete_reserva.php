<?php

include("conexion.php");
$con = connection();

$idProducto=$_GET["idReserva"];

$sql="DELETE FROM reserva WHERE idReserva='$idReserva'";
$query = mysqli_query($con, $sql);

if($query){
    Header("Location: select_reserva.php");
}else{

}

?>